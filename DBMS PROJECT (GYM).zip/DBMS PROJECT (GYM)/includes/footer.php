<?php
?>

<footer style="text-align: center; margin-top: 30px; padding: 10px; background-color: #333; color: #eee; border-radius: 5px;">
    &copy; <?php echo date("Y"); ?> Your Gym Management System. All rights reserved.
    <br>
    Powered by Your Awesome Development Team
    <p style="font-size: 0.8em; color: #999; margin-top: 5px;">
        Located in Coimbatore, Tamil Nadu, India.
    </p>
</footer>

</body>
</html>